package com.clp.entity;

public enum FileType {
	Video,
	Image,
	Text
}
